import os
from typing import Any, Optional

from src.scraper.scrape_player import PlayerLogScraper
from src.scraper.scrape_roster import TeamRosterScraper
from src.loader.s3_bronze import save_bronze_s3
from utils.config import Config


def handler(event: Optional[dict[str, Any]], context: Any) -> dict[str, Any]:
    request = event or {}
    season = request.get("season", "2025")
    competition = request.get("competition")

    bucket = os.environ["S3_BUCKET"]
    bronze_prefix = os.environ.get("S3_BRONZE_PREFIX", "bronze")

    config = Config()
    roster_scraper = TeamRosterScraper(config=config)
    player_scraper = PlayerLogScraper(config=config, roster_scraper=roster_scraper)

    squad_players = roster_scraper.get_squad_players(season)
    roster_payload = roster_scraper.build_roster_payload(season, squad_players)
    save_bronze_s3(
        data=roster_payload,
        source="transfermarkt",
        data_type="team_roster",
        season=season,
        bucket=bucket,
        bronze_prefix=bronze_prefix,
    )

    total_rows = 0
    for player in squad_players:
        payload = player_scraper.run_player(
            player_url=player["player_url"],
            season=season,
            competition=competition,
        )
        save_bronze_s3(
            data=payload,
            source="transfermarkt",
            data_type="player_detailed_stats",
            season=season,
            bucket=bucket,
            bronze_prefix=bronze_prefix,
            entity=player_scraper.client.player_storage_key(
                payload["player_name"],
                payload["player_id"],
            ),
        )
        total_rows += len(payload["player_stats"])

    return {
        "statusCode": 200,
        "club": config.CLUB_NAME,
        "season": season,
        "players_scraped": len(squad_players),
        "total_rows": total_rows,
    }
