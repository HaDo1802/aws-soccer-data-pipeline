import json
from datetime import datetime, timezone
from typing import Optional

import boto3

from utils.logger import get_logger


LOGGER = get_logger(__name__)


def save_bronze_s3(
    data: dict,
    source: str,
    data_type: str,
    season: str,
    bucket: str,
    bronze_prefix: str = "bronze",
    entity: Optional[str] = None,
) -> str:
    key_parts = [bronze_prefix, source, data_type]
    if entity is not None:
        key_parts.append(entity)
    key_parts.extend(
        [
            f"season={season}",
            f"scrape_date={datetime.now(timezone.utc).date().isoformat()}.json",
        ]
    )
    key = "/".join(key_parts)

    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(data, indent=2).encode("utf-8"),
        ContentType="application/json",
    )
    LOGGER.info("Wrote bronze data to s3://%s/%s", bucket, key)
    return key
