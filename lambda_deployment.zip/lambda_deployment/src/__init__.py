"""Core project package."""
