from dataclasses import dataclass, field


@dataclass(frozen=True)
class Config:
    CLUB_NAME: str = "Manchester United"
    TRANSFERMARKT_CLUB_SLUG: str = "manchester-united"
    TRANSFERMARKT_CLUB_ID: str = "985"
    TRANSFERMARKT_BASE_URL: str = "https://www.transfermarkt.us"
    TRANSFERMARKT_DEFAULT_COMPETITION: str = "GB1"
    SEASONS: list[str] = field(
        default_factory=lambda: [
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
        ]
    )
    SEASON_LABELS: dict[str, str] = field(
        default_factory=lambda: {
            "2021": "2021/2022",
            "2022": "2022/2023",
            "2023": "2023/2024",
            "2024": "2024/2025",
            "2025": "2025/2026",
        }
    )
    LOCAL_BRONZE_ROOT: str = "data/bronze"
    LOCAL_SILVER_ROOT: str = "data/silver"
    S3_BUCKET: str = "sport-analysis"
    S3_BRONZE_PREFIX: str = "bronze"
    S3_SILVER_PREFIX: str = "silver"
    REQUEST_DELAY_SECONDS: int = 4
    MAX_RETRIES: int = 3
