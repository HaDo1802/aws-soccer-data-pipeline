"""Shared Lambda deployment utilities."""
